AngularJs Formation.

To start from fresh with a minimal html markup and basic file structure, clone the repository then from your git shell execute the following:

```
$ git checkout 0.0.0
```
There are a few tags for every step in building the todo app.

The final result of the working todo list is on the master branch.

The french step-by-step is here: <https://drive.google.com/file/d/0B9HVbv29cDuvOFZkS0Q1a2JuS3c/view?usp=sharing>

The step-by-step is in french but will soon be available in english also.

For any request feel free to get in touch.

@Copyright Khalid Sookia